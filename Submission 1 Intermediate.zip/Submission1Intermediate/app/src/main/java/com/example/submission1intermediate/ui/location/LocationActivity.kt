package com.example.submission1intermediate.ui.location

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.submission1intermediate.R
import com.example.submission1intermediate.databinding.ActivityLocationBinding

class LocationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLocationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLocationBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}