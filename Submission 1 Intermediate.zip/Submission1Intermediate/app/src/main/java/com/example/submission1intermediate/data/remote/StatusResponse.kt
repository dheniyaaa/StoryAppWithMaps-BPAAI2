package com.example.submission1intermediate.data.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}