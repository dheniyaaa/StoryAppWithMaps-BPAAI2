package com.example.submission1intermediate.ui.detail

class DetailStoryViewModel