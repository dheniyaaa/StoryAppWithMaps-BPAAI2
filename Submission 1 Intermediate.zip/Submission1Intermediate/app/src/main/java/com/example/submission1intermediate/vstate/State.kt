package com.example.submission1intermediate.vstate

enum class State {
    SUCCESS,
    ERROR,
    LOADING
}